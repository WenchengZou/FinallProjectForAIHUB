
picture=15

def change():
    global  picture
    picture=picture+1

def get():
    return picture