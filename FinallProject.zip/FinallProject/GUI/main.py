from flask import Flask, render_template, request, url_for, redirect, session
import pandas as pd
import datetime
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.dates as mdates
import GUI.StoreGlobal as S

app = Flask(__name__)
app.secret_key = 'abcdefgh!@#$%'


@app.route('/',methods=['POST','GET'])
def index():
    df=pd.read_csv('../Dataset/us_daily.csv')
    column=[]
    for columns in df:
        column.append(columns)
    return render_template('Interface.html',column=column)


@app.route('/check',methods=['POST','GET'])
def check():
    column1=request.form.get('type')
    column2=request.form.get('type2')
    print(column1)
    print(column2)
    if(column1=='date'):
        df = pd.read_csv('../Dataset/us_daily.csv')
        times = []
        for i in df.values:
           times.append(pd.to_datetime(str(datetime.datetime(int(str(i[0])[:4]), int(str(i[0])[4:6]), int(str(i[0])[6:])))))
        plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
        plt.gca().xaxis.set_major_locator(mdates.DayLocator(interval=10))
        plt.figure(figsize=(16, 7))  # 左边的参数表示宽，右边的参数表示高
        plt.scatter(times, df[column2], color='red')
        plt.xlabel(column1)
        plt.ylabel(column2)
        strn='../Model/en{}.jpg'.format(S.get())
        S.change()
        plt.savefig(strn)
    else:
        df = pd.read_csv('../Dataset/us_daily.csv')
        plt.figure(figsize=(16, 7))  # 左边的参数表示宽，右边的参数表示高
        plt.scatter(df[column1], df[column2], color='red')
        plt.xlabel(column1)
        plt.ylabel(column2)
        strn = '../Model/en{}.jpg'.format(S.get())
        S.change()
        plt.savefig(strn)
    column = []
    for columns in df:
        column.append(columns)
    return render_template('Interface.html',column=column)


if __name__ == '__main__':
    app.run(debug=True)
